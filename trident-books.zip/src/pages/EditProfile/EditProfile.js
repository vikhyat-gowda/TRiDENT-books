import React from "react";

export default function EditProfile() {
  return (
    <div className="flex h-screen justify-center items-center dark:bg-primaryDark">
      <div className="bg-primaryLight flex">
        <div className="Edit Profile dark:text-primaryText">
          <p className="">Edit Profile coming soon</p>
        </div>
      </div>
    </div>
  );
}
